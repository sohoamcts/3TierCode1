﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using nsMyProject;

using System.Data;
public partial class _Default : System.Web.UI.Page
{
    
    clsPrpUser objPrp = new clsPrpUser();
    clsUser objMain = new clsUser();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GrdBInd();
        }
    }
    private void GrdBInd()
    {//show data in gridview
        GridView1.DataSource = objMain.display();
        GridView1.DataBind();
    }
   
    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
        objPrp.sName = txtName.Text;
        objPrp.sPassword = txtPasswword.Text;
        objPrp.sEmail = txtEmail.Text;
        objMain.saveUser(objPrp);
        GrdBInd();
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        objPrp.iUserId=Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
        objMain.deleteUser(objPrp);
        GrdBInd();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dtUser = new DataTable();
          objPrp.iUserId=Convert.ToInt32(GridView1.SelectedDataKey.Value);
          dtUser = objMain.displayById(objPrp);
          if (dtUser.Rows.Count > 0)
          {
              txtName.Text = dtUser.Rows[0][1].ToString();
              txtPasswword.Text = dtUser.Rows[0][2].ToString();
              txtEmail.Text = dtUser.Rows[0][3].ToString();


          }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {//update data
        objPrp.iUserId = Convert.ToInt32(GridView1.SelectedDataKey.Value);
        objPrp.sName = txtName.Text;
        objPrp.sPassword = txtPasswword.Text;
        objPrp.sEmail = txtEmail.Text;
        objMain.updateUser(objPrp);
      
        GrdBInd();

    }
}