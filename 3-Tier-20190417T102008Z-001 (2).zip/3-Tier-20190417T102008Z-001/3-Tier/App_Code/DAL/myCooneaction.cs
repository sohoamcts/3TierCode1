﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;
/// <summary>
/// Summary description for myCooneaction
/// </summary>
/// 

namespace nsMyProject
{
public abstract  class myCooneaction
{
    protected SqlConnection objConn=new SqlConnection ();

	public myCooneaction()
	{

        objConn.ConnectionString = ConfigurationManager.ConnectionStrings["mycts"].ConnectionString;
		//
		// TODO: Add constructor logic here
		//
	}
}
}