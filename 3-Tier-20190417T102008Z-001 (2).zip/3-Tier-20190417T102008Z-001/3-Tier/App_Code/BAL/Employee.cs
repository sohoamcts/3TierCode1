﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for Employee
/// </summary>
/// 
namespace nsMyProject
{

    public interface intUser
    {
        Int32 iUserId
        {
            get;
            set;
        }
        string sName
        {
            get;
            set;
        }
        string sPassword
        {
            get;
            set;
        }
        string sEmail
        {
            get;
            set;
        }
    }
    //right click on the name interface then click on implement interface
    public class clsPrpUser:intUser 
    {

        private Int32 _iUserId;
        private string _sName, _sPasswrod, _sEmail;
        public int iUserId
        {
            get
            {
                return _iUserId;
            }
            set
            {
                _iUserId = value;
            }
        }

        public string sName
        {
            get
            {
                return _sName;
            }
            set
            {
                _sName = value;
            }
        }

        public string sPassword
        {
            get
            {
                return _sPasswrod;
            }
            set
            {
                _sPasswrod = value;
            }
        }

        public string sEmail
        {
            get
            {
                return _sEmail;
            }
            set
            {
                _sEmail = value;
            }
        }
    }
    public class clsUser:myCooneaction 
    {
        SqlCommand objCmd = new SqlCommand();
        public void saveUser(clsPrpUser objPrp) //obPrp is object of class clsprpUser
        {
            if (objConn.State == ConnectionState.Closed)
            {
                objConn.Open();
            }
            objCmd.Connection = objConn;
            objCmd.CommandText = "insert into tbUserLogin values(@sName,@sPassword,@sEmail)";
            objCmd.Parameters.Add("@sName", SqlDbType.VarChar, 50).Value = objPrp.sName;
            objCmd.Parameters.Add("@sPassword", SqlDbType.VarChar, 50).Value = objPrp.sPassword;
            objCmd.Parameters.Add("@sEmail", SqlDbType.VarChar, 50).Value = objPrp.sEmail;
            objCmd.ExecuteNonQuery();
            objCmd.Dispose();
            objConn.Close();
        }
        public void updateUser(clsPrpUser objPrp)
        {
            if (objConn.State == ConnectionState.Closed)
            {
                objConn.Open();
            }
            objCmd.Connection = objConn;
            objCmd.CommandText = "update tbUserLogin set sName=@sName,sPassword=@sPassword,sEmail=@sEmail where iUserId=@iUserId";
            objCmd.Parameters.Add("@iUserId", SqlDbType.Int).Value = objPrp.iUserId;
            objCmd.Parameters.Add("@sName", SqlDbType.VarChar, 50).Value = objPrp.sName;
            objCmd.Parameters.Add("@sPassword", SqlDbType.VarChar, 50).Value = objPrp.sPassword;
            objCmd.Parameters.Add("@sEmail", SqlDbType.VarChar, 50).Value = objPrp.sEmail;
            objCmd.ExecuteNonQuery();
            objCmd.Dispose();
            objConn.Close();
        }
        public DataTable display()
        {
            SqlDataAdapter objAdp = new SqlDataAdapter("select * from tbUserLogin", objConn);
            DataTable dtUser = new DataTable();
            objAdp.Fill(dtUser);
            return dtUser;
        }

        public DataTable displayById(clsPrpUser objPrp)
        {
            SqlDataAdapter objAdp = new SqlDataAdapter("select * from tbUserLogin where iUserId="+objPrp.iUserId, objConn);
            DataTable dtUser = new DataTable();
            objAdp.Fill(dtUser);
            return dtUser;
        }
        public void deleteUser(clsPrpUser objPrp)
        {
            if (objConn.State == ConnectionState.Closed)
            {
                objConn.Open();
            }
            objCmd.Connection = objConn;
            objCmd.CommandText = "delete from tbUserLogin where iUserId=@iUserId";
            objCmd.Parameters.Add("@iUserId", SqlDbType.Int).Value = objPrp.iUserId;
            
            objCmd.ExecuteNonQuery();
            objCmd.Dispose();
            objConn.Close();
        }
        
    
    }
}